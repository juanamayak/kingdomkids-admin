import { Component } from '@angular/core';

@Component({
    selector: 'app-deleted-contracts',
    imports: [],
    templateUrl: './deleted-contracts.component.html',
    styleUrl: './deleted-contracts.component.scss'
})
export class DeletedContractsComponent {

}
