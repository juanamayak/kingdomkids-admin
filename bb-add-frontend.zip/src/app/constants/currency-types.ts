export const CurrencyTypes = [
    {
        name: 'MXN',
    },
    {
        name: 'USD'
    }
];
