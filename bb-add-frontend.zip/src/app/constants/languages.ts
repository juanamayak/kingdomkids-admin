export const Languages = [
    {
        name: 'Español',
        value: 'ESP'
    },
    {
        name: 'Inglés',
        value: 'ING'
    }
]
