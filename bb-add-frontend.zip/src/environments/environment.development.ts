export const environment = {
    production: false,
    // urlApi: 'http://192.168.10.59:8040/api' // API COSO
    urlApi: 'http://localhost:3001/api'
};
