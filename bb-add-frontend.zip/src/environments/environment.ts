export const environment = {
  production: true,
  urlApi: 'https://api.flyback.com.mx/buyback-service/add/testing/api'
};
